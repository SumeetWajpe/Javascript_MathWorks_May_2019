
      
function Course(theId,theTitle,theDuration,theImageUrl,theLikes){
    this.id = theId;
    this.title = theTitle;
    this.imageUrl = theImageUrl;
    this.duration = theDuration;
    this.likes = theLikes; 
}

// var allCourses = [
//     new Course(1,"Angular",'5 Days','https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Angular_full_color_logo.svg/250px-Angular_full_color_logo.svg.png',100),
//     new Course(2,"Node",'3 Days','https://d2eip9sf3oo6c2.cloudfront.net/tags/images/000/000/256/full/nodejslogo.png',300),
//     new Course(3,"Redux",'2 Days','https://cdn-images-1.medium.com/max/1600/1*BpaqVMW2RjQAg9cFHcX1pw.png',300),
//     new Course(4,".NET",'6 Days','https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/.NET_Core_Logo.svg/1200px-.NET_Core_Logo.svg.png',300),
//     new Course(5,"JAVA",'8 Days','https://www.sjpl.org/sites/default/files/events/images/2019/03/javalogo.jpg',300)
// ];

var allCourses = [];
function GetPosts(){
    var xmlHttpObj = new XMLHttpRequest();
    xmlHttpObj.onreadystatechange = function(){
     console.log(xmlHttpObj.readyState);
     if(xmlHttpObj.readyState == 4 && xmlHttpObj.status == 200){
         // update DOM !
        
         allCourses = JSON.parse(xmlHttpObj.responseText); 
         var divRow = document.querySelector('.row');
         for(var course of allCourses){
            CreateCourseComponent(course,divRow);
        }
     }
 }// eof readyState

 xmlHttpObj.open("GET","http://localhost:3000/courses");
 xmlHttpObj.send(); // make an AJAX call !
}

GetPosts();

function CreateCourseComponent(theCourse,theParent){
    var newCourseColumn = document.createElement('div');
    newCourseColumn.className = "col-md-3";
    newCourseColumn.classList.add("CourseStyle");

    var newTitle = document.createElement('h3');
    newTitle.innerHTML = theCourse.title;

    var newImage = document.createElement('img');
    newImage.style = "height:200px;width:200px";
    newImage.className = "img-thumbnail";
    newImage.src = theCourse.imageUrl;

    var newDuration = document.createElement('h4');
    newDuration.innerHTML = "<b>Duration : " + theCourse.duration + "</b>";

    var newLikesButton = document.createElement('button');
    newLikesButton.className = "btn btn-primary";
    newLikesButton.id = "btnCourseLikes" + theCourse.id;
    newLikesButton.innerHTML = theCourse.likes + "<span class='glyphicon glyphicon-thumbs-up'></span>"
    newLikesButton.addEventListener('click',IncrementLikes.bind(this,theCourse));

    var newDeleteButton = document.createElement('button');
    newDeleteButton.className = "btn btn-danger";
    newDeleteButton.id = "btnCourseDelete" + theCourse.id;
    newDeleteButton.addEventListener('click',DeleteEventHandler.bind(this))
    newDeleteButton.innerHTML = "<span class='glyphicon glyphicon-trash'></span>"


    newCourseColumn.appendChild(newTitle);
    newCourseColumn.appendChild(newImage);
    newCourseColumn.appendChild(newDuration);
    newCourseColumn.appendChild(newLikesButton);
    newCourseColumn.appendChild(newDeleteButton);    
    theParent.appendChild(newCourseColumn);
}

function IncrementLikes(theCourse){   
    var e = event;
    if(e.target.nodeName == "SPAN"){
           theCourse.likes+=1; 
           e.target.parentNode.innerHTML = theCourse.likes + "<span class='glyphicon glyphicon-thumbs-up'></span>"
    }
    else if(e.target.nodeName == "BUTTON"){
        theCourse.likes+=1;    
        e.target.innerHTML = theCourse.likes + "<span class='glyphicon glyphicon-thumbs-up'></span>"
}
   }


function DeleteEventHandler(){   
    var e = event;
        if(e.target.nodeName == "SPAN"){
               e.target.parentNode.parentNode.parentNode.removeChild(e.target.parentNode.parentNode);
        }
        else if(e.target.nodeName == "BUTTON"){
             e.target.parentNode.parentNode.removeChild(e.target.parentNode);
        }
}
