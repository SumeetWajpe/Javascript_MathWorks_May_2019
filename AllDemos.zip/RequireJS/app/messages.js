define(function () {   
    return {
        getHello: function () {
            return 'Hello Require JS !';
        }
    };
});
