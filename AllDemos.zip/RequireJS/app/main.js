define(function () {
   return{
       name:'Main File data'
   }
});
