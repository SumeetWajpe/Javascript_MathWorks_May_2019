// Selective Import 
// import {Add,PI} from './Math.js';
// console.log(Add(50,30));


// Default import 
import Multiplication,{Add} from './Math.js';
console.log(Multiplication(50,30));


// Global Imports
// import * as MathModule from './Math.js';
// console.log(MathModule.Add(20,30));