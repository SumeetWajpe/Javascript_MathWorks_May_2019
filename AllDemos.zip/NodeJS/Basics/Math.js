function Add(x,y){
    return x + y;
}

function Multiply(x,y){
    return x * y;
}

module.exports = {Add:Add,Multiply:Multiply};