module.exports = function Course(theId,theTitle,theDuration,theImageUrl,theLikes){
    this.id = theId;
    this.title = theTitle;
    this.imageUrl = theImageUrl;
    this.duration = theDuration;
    this.likes = theLikes; 
}