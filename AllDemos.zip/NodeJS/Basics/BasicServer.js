const http = require('http');
var express = require('express');
var cors = require('cors');
var app = express();
var Course = require('./course.model');
app.use(cors());



const hostname = '127.0.0.1';
const port = 3000;

app.get('/',(req,res)=>{
        res.sendFile('Index.html',{root:__dirname})
});

app.get('/courses',(req,res)=>{
var allCourses = [
    new Course(1,"Angular",'5 Days','https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Angular_full_color_logo.svg/250px-Angular_full_color_logo.svg.png',100),
    new Course(2,"Node",'3 Days','https://d2eip9sf3oo6c2.cloudfront.net/tags/images/000/000/256/full/nodejslogo.png',300),
    new Course(3,"Redux",'2 Days','https://cdn-images-1.medium.com/max/1600/1*BpaqVMW2RjQAg9cFHcX1pw.png',300),
    new Course(4,".NET",'6 Days','https://upload.wikimedia.org/wikipedia/commons/thumb/e/ee/.NET_Core_Logo.svg/1200px-.NET_Core_Logo.svg.png',300),
    new Course(5,"JAVA",'8 Days','https://www.sjpl.org/sites/default/files/events/images/2019/03/javalogo.jpg',300)
];
    res.json(allCourses);
});
app.get('/products',(req,res)=>{
    var products = [
        {name:'Laptop',price:40000},
        {name:'TV',price:30000},
        {name:'DSLR',price:70000},
        {name:'Go Pro',price:30000}
];

    res.json(products);
});

// get a specific product
app.get('/products/:id',(req,res)=>{
    var products = [
        {id:1,name:'Laptop',price:40000},
        {id:2,name:'TV',price:30000},
        {id:3,name:'DSLR',price:70000},
        {id:4,name:'Go Pro',price:30000}
];

console.log(req.params.id);
    res.json(products.filter(p=>p.id == req.params.id));
});

app.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});