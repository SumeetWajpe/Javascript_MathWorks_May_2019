var MathModule = require('./Math');
console.log(MathModule.Add(20,50));